function download(string) {
    let item = string;
    if(item == 'dchb') {
        window.open('/download/discord-webhock-spammer.html', '_blank');
    } else if(item == 'ddos') {
        window.open('/download/ddos.html', '_blank');
    } else if(item == 'terminal') {
        window.open('/download/terminal.html', '_blank');
    } else {
        window.open('/download/404.html', '_blank');
    }
}