function downloadwb(string) {
    let version = string;
    if(version == '1') {
        window.open('https://downgit.evecalm.com/#/home?url=https://github.com/OneBoyOG/THABOYS-WEB/blob/main/DcWHSpmer.bat', '_blank');
    } else if(version == '2') {
        window.open('https://downgit.evecalm.com/#/home?url=https://github.com/OneBoyOG/THABOYS-WEB/blob/main/DcWHSpmer.bat', '_blank');
    } else if(version == '3') {
        window.open('https://downgit.evecalm.com/#/home?url=https://github.com/OneBoyOG/THABOYS-WEB/blob/main/DcWHSpmer.bat', '_blank');
    } else {
        window.open('/download/404.html', '_blank');
    }
}